export interface Song {
    "id": Number,
    "Name": String,
    "Singers": String,
    "Year": Number,
    "Album": String,
    "Genre": String
}